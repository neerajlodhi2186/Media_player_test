package com.lodhi.neeraj.myjioapp;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.app.NotificationCompat;

import com.lodhi.neeraj.myjioapp.service.MusicService;



/**
 * Created by Neeraj on 2/16/2019.
 */

public class NotificationHelper {

    public static final String ACTION_PAUSE = "ACTION_PAUSE";

    public static final String ACTION_PLAY = "ACTION_PLAY";

    public static final String ACTION_PREV = "ACTION_PREV";

    public static final String ACTION_NEXT = "ACTION_NEXT";

    /**
     * Build a notification using the information from the given media session. Makes heavy use
     *
     */
    public static Notification getNotification(
            Context context,boolean status,String songTitle) {
        final String channelId ="musicNotificaton";

        Intent notIntent = new Intent(context, MainActivity.class);
        notIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendInt = PendingIntent.getActivity(context, 0,
                notIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, notIntent, 0);
        //PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);

        // Create notification builder.
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context,channelId);

        // Make notification show big text.
        NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle();
        bigTextStyle.setBigContentTitle(songTitle);
        // bigTextStyle.bigText("Android foreground service is a android service which can run in foreground always, it can be controlled by user via notification.");
        // Set big text style.
        builder.setStyle(bigTextStyle);

        builder.setWhen(System.currentTimeMillis());
        builder.setSmallIcon(R.mipmap.ic_launcher);
        Bitmap largeIconBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.ic_launcher_foreground);
        builder.setLargeIcon(largeIconBitmap);
        // Make the notification max priority.
        builder.setPriority(Notification.PRIORITY_MAX);
        // Make head-up notification.
        builder.setFullScreenIntent(pendingIntent, true);

        // Add Prev button intent in notification.
        Intent nextIntent = new Intent(context, MusicService.class);
        nextIntent.setAction(ACTION_NEXT);
        PendingIntent pendingnextIntent = PendingIntent.getService(context, 0, nextIntent, 0);
        NotificationCompat.Action nextAction = new NotificationCompat.Action(android.R.drawable.ic_media_pause, "Next", pendingnextIntent);
        builder.addAction(nextAction);


        // Add Prev button intent in notification.
        Intent prevIntent = new Intent(context, MusicService.class);
        prevIntent.setAction(ACTION_PREV);
        PendingIntent pendingPrevIntent = PendingIntent.getService(context, 0, prevIntent, 0);
        NotificationCompat.Action prevAction = new NotificationCompat.Action(android.R.drawable.ic_media_pause, "Prev", pendingPrevIntent);
        builder.addAction(prevAction);

        if(status){
            // Add Pause button intent in notification.
            Intent pauseIntent = new Intent(context, MusicService.class);
            pauseIntent.setAction(ACTION_PAUSE);
            PendingIntent pendingpauseIntent = PendingIntent.getService(context, 0, pauseIntent, 0);
            NotificationCompat.Action pauseAction = new NotificationCompat.Action(android.R.drawable.ic_media_pause, "Pause", pendingpauseIntent);
            builder.addAction(pauseAction);
        }
        else
        {
            // Add Play button intent in notification.
            Intent playIntent = new Intent(context, MusicService.class);
            playIntent.setAction(ACTION_PLAY);
            PendingIntent pendingPlayIntent = PendingIntent.getService(context, 0, playIntent, 0);
            NotificationCompat.Action playAction = new NotificationCompat.Action(android.R.drawable.ic_media_play, "Play", pendingPlayIntent);
            builder.addAction(playAction);

        }

        // Build the notification.
        Notification notification = builder.build();
        return notification;
    }
}
