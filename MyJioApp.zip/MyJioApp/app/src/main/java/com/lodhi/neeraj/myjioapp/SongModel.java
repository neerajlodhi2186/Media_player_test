package com.lodhi.neeraj.myjioapp;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;

import java.util.ArrayList;

/**
 * Created by Neeraj on 2/16/2019.
 */

public class SongModel implements MusicMainInterface.PresenterToModel {

    private MusicMainInterface.MOdelToPresenter mPresenter;
    public SongModel(MusicMainInterface.MOdelToPresenter mOdelToPresenter) {
        mPresenter = mOdelToPresenter;
    }

    @Override
    public ArrayList<Song> getSongList() {

        ArrayList<Song> songList = new ArrayList<>();
        try {
            //query external audio
            ContentResolver musicResolver = mPresenter.getContext().getContentResolver();
            Uri musicUri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            Cursor musicCursor = musicResolver.query(musicUri, null, null, null, null);
            //iterate over results if valid
            if (musicCursor != null && musicCursor.moveToFirst()) {
                //get columns
                int titleColumn = musicCursor.getColumnIndex
                        (android.provider.MediaStore.Audio.Media.TITLE);
                int idColumn = musicCursor.getColumnIndex
                        (android.provider.MediaStore.Audio.Media._ID);
                int artistColumn = musicCursor.getColumnIndex
                        (android.provider.MediaStore.Audio.Media.ARTIST);
                //add songs to list
                do {
                    long thisId = musicCursor.getLong(idColumn);
                    String thisTitle = musicCursor.getString(titleColumn);
                    String thisArtist = musicCursor.getString(artistColumn);
                    songList.add(new Song(thisId, thisTitle, thisArtist));
                }
                while (musicCursor.moveToNext());
            }
        }
        catch (Exception e){
            return songList;
        }
        return songList;

        //return null;
    }
}
