package com.lodhi.neeraj.myjioapp;

/**
 * Created by Neeraj on 2/9/2019.
 */

import android.content.Context;
import android.widget.MediaController;


public class MusicController extends MediaController {

    public MusicController(Context c){
        super(c);
    }

    public void hide(){}

}