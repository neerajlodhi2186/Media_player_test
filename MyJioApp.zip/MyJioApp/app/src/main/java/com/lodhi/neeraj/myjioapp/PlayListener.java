package com.lodhi.neeraj.myjioapp;

/**
 * Created by Neeraj on 2/16/2019.
 */

public interface PlayListener {

     void playSong();
     void playNext();
     void playPrev();
     void pausePlayer();

}
