package com.lodhi.neeraj.myjioapp.service;

import android.app.Notification;
import android.app.Service;
import android.content.ContentUris;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;

import android.util.Log;
import android.widget.Toast;

import com.lodhi.neeraj.myjioapp.FloatingView;
import com.lodhi.neeraj.myjioapp.NotificationHelper;
import com.lodhi.neeraj.myjioapp.PlayListener;
import com.lodhi.neeraj.myjioapp.Song;

import java.util.ArrayList;
import java.util.Random;

import static com.lodhi.neeraj.myjioapp.NotificationHelper.ACTION_NEXT;
import static com.lodhi.neeraj.myjioapp.NotificationHelper.ACTION_PAUSE;
import static com.lodhi.neeraj.myjioapp.NotificationHelper.ACTION_PLAY;
import static com.lodhi.neeraj.myjioapp.NotificationHelper.ACTION_PREV;


public class MusicService extends Service implements
        MediaPlayer.OnPreparedListener, MediaPlayer.OnErrorListener,
        MediaPlayer.OnCompletionListener,PlayListener {

    //media mPlayer
    private MediaPlayer mPlayer;
    //song list
    private ArrayList<Song> mSongs;
    //current position
    private int mSongPosn;
    //binder
    private final IBinder mMusicBind = new MusicBinder();
    //title of current song
    private String mSongTitle ="";
    //notification id
    private static final int mNOTIFY_ID =1;
    //mShuffle flag and random
    private boolean mShuffle =false;
    private Random mRandom;

    // floating view
    private FloatingView mFloatingView ;

    public void onCreate(){
        //create the service
        super.onCreate();
        //initialize position
        mSongPosn =0;
        //random
        mRandom =new Random();
        //create mPlayer
        mPlayer = new MediaPlayer();
        //initialize
        initMusicPlayer();

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
            mFloatingView = new FloatingView(MusicService.this);
            mFloatingView.initFloatingView();

        }
    }



    public void initMusicPlayer(){
        //set mPlayer properties
        mPlayer.setWakeMode(getApplicationContext(),
                PowerManager.PARTIAL_WAKE_LOCK);
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        //set listeners
        mPlayer.setOnPreparedListener(this);
        mPlayer.setOnCompletionListener(this);
        mPlayer.setOnErrorListener(this);
    }

    //pass song list
    public void setList(ArrayList<Song> theSongs){
        mSongs =theSongs;
    }

    //binder
    public class MusicBinder extends Binder {
        public MusicService getService() {
            return MusicService.this;
        }
    }

    //activity will bind to service
    @Override
    public IBinder onBind(Intent intent) {
        return mMusicBind;
    }

    //release resources when unbind
    @Override
    public boolean onUnbind(Intent intent){
        mPlayer.stop();
        mPlayer.release();
        return false;
    }

    //play a song
    public void playSong(){
        //play
        mPlayer.reset();
        //get song
        Song playSong = mSongs.get(mSongPosn);
        //get title
        mSongTitle =playSong.getTitle();
        //get id
        long currSong = playSong.getID();
        //set uri
        Uri trackUri = ContentUris.withAppendedId(
                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                currSong);
        //set the data source
        try{
            mPlayer.setDataSource(getApplicationContext(), trackUri);
        }
        catch(Exception e){
            Log.e("MUSIC SERVICE", "Error setting data source", e);
        }
        mPlayer.prepareAsync();

    }

    //set the song
    public void setSong(int songIndex){
        mSongPosn =songIndex;
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        //check if playback has reached the end of a track
        if(mPlayer.getCurrentPosition()>0){
            mp.reset();
            playNext();
        }
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        Log.v("MUSIC PLAYER", "Playback Error");
        mp.reset();
        return false;
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        //start playback
        mp.start();
        //notification
        addNotification(true);

    }

    public void addNotification(boolean status)
    {
        // get Notification using Notification helper.
       // Notification notification = builder.build();
        Notification notification = NotificationHelper.getNotification(MusicService.this,status, mSongTitle);

        // Start foreground service.
        startForeground(mNOTIFY_ID, notification);
    }


    //playback methods
    public int getPosn(){
        return mPlayer.getCurrentPosition();
    }

    public int getDur(){
        return mPlayer.getDuration();
    }

    public boolean isPng(){
        return mPlayer.isPlaying();
    }

    public void pausePlayer(){
        mPlayer.pause();
    }

    public void seek(int posn){
        mPlayer.seekTo(posn);
    }

    public void go(){
        mPlayer.start();
    }

    //skip to previous track
    public void playPrev(){
        mSongPosn--;
        if(mSongPosn <0) mSongPosn = mSongs.size()-1;
        playSong();
    }

    //skip to next
    public void playNext(){
        if(mShuffle){
            int newSong = mSongPosn;
            while(newSong== mSongPosn){
                newSong= mRandom.nextInt(mSongs.size());
            }
            mSongPosn =newSong;
        }
        else{
            mSongPosn++;
            if(mSongPosn >= mSongs.size()) mSongPosn =0;
        }
        playSong();
    }

    @Override
    public void onDestroy() {
        if (mFloatingView != null) mFloatingView.removeFloatingView();
        stopForeground(true);
    }

    //toggle mShuffle
    public void setShuffle(){
        if(mShuffle) mShuffle =false;
        else mShuffle =true;
    }



    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if(intent != null && intent.getAction() !=null )
        {
            String action = intent.getAction();

            switch (action)
            {

                case ACTION_PLAY:
                    addNotification(true);
                    playSong();
                    break;
                case ACTION_PAUSE:
                    addNotification(false);
                    pausePlayer();
                    break;
                case ACTION_PREV:
                    playPrev();
                    break;
                case ACTION_NEXT:
                    playNext();
                    break;
            }
        }
        return super.onStartCommand(intent, flags, startId);
    }



}

