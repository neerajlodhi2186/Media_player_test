package com.lodhi.neeraj.myjioapp;

import java.util.ArrayList;


/**
 * Created by Neeraj on 2/16/2019.
 */

public interface SongActivityView {




        void displySongList(ArrayList<Song> songList);



}
