package com.lodhi.neeraj.myjioapp;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.MediaController;
import android.widget.Toast;

import com.lodhi.neeraj.myjioapp.service.MusicService;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity implements SongActivityView,MediaController.MediaPlayerControl {

    private MusicPresenter mPresenter;
    private ArrayList<Song> songList = new ArrayList<>();;

    private RecyclerView mRecyclerView;
    private SongRecycleAdapter mAdapter;

    //service
    private MusicService mMusicService;
    private Intent mPlayIntent;
    //binding
    private boolean mMusicBound = false;
    //activity and playback pause flags
    private boolean mPaused = false, mPlaybackPaused =false;

    //mController
    private MusicController mController;

    private static final int CODE_DRAW_OVER_OTHER_APP_PERMISSION = 2083;

    //connect to the service
    private ServiceConnection musicConnection = new ServiceConnection(){

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.MusicBinder binder = (MusicService.MusicBinder)service;
            //get service
            mMusicService = binder.getService();
            //pass list
            mMusicService.setList(songList);
            mMusicBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mMusicBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {


            //If the draw over permission is not available open the settings screen
            //to grant the permission.
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, CODE_DRAW_OVER_OTHER_APP_PERMISSION);

            finish();
        }

        mPresenter = new MusicPresenter(new MusicMainInterface.PresenterToView() {
            @Override
            public Context getContext() {
                return MainActivity.this;
            }
        },MainActivity.this);

        // initialize view
        initializeView();

        if( mPresenter.checkPermission())
        {
            Toast.makeText(MainActivity.this, "Permission already granted.", Toast.LENGTH_SHORT).show();
            mPresenter.getSongList();
            //setup
           setController();
        }
        else
        {
            mPresenter.requestPermission();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //menu item selected
        switch (item.getItemId()) {
            case R.id.action_end:
                stopService(mPlayIntent);
                mMusicService =null;
                System.exit(0);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    //start and bind the service when the activity starts
    @Override
    protected void onStart() {
        super.onStart();
        if(mPlayIntent ==null){
            mPlayIntent = new Intent(this, MusicService.class);
            bindService(mPlayIntent, musicConnection, Context.BIND_AUTO_CREATE);
            startService(mPlayIntent);
        }
    }
    @Override
    protected void onPause(){
        super.onPause();
        mPaused =true;
    }

    @Override
    protected void onResume(){
        super.onResume();
        if(mPaused){
            setController();
            mPaused =false;
        }
    }

    @Override
    protected void onStop() {
        mController.hide();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        if(mPlayIntent != null) stopService(mPlayIntent);
        mMusicService =null;
        super.onDestroy();
    }


    private void initializeView(){
        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);


        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(MainActivity.this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());

        mRecyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), mRecyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                Song song = songList.get(position);
                Toast.makeText(getApplicationContext(), song.getTitle() + " is selected!", Toast.LENGTH_SHORT).show();
                songPicked(position);

            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission granted and now can proceed
                    mPresenter.getSongList(); //a sample method called

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(MainActivity.this, "Permission denied to read your External storage", Toast.LENGTH_SHORT).show();
                    //finish();
                }
                return;
            }
            // add other cases for more permissions
        }
    }

    @Override
    public void displySongList(ArrayList<Song> songList) {
        this.songList = songList;
        //pass list

        Log.e("Main",songList.get(0).getTitle());
        //sort alphabetically by title
        Collections.sort(songList, new Comparator<Song>(){
            public int compare(Song a, Song b){
                return a.getTitle().compareTo(b.getTitle());
            }
        });
        if(mMusicService != null) mMusicService.setList(songList);
        mAdapter = new SongRecycleAdapter(songList);
        mRecyclerView.setAdapter(mAdapter);
    }



    @Override
    public boolean canPause() {
        return true;
    }

    @Override
    public boolean canSeekBackward() {
        return true;
    }

    @Override
    public boolean canSeekForward() {
        return true;
    }

    @Override
    public int getAudioSessionId() {
        return 0;
    }

    @Override
    public int getBufferPercentage() {
        return 0;
    }

    @Override
    public int getCurrentPosition() {
        if(mMusicService !=null && mMusicBound && mMusicService.isPng())
            return mMusicService.getPosn();
        else return 0;
    }

    @Override
    public int getDuration() {
        if(mMusicService !=null && mMusicBound && mMusicService.isPng())
            return mMusicService.getDur();
        else return 0;
    }

    @Override
    public boolean isPlaying() {
        if(mMusicService !=null && mMusicBound)
            return mMusicService.isPng();
        return false;
    }

    @Override
    public void pause() {
        mPlaybackPaused =true;
        mMusicService.pausePlayer();
    }

    @Override
    public void seekTo(int pos) {
        mMusicService.seek(pos);
    }

    @Override
    public void start() {
        mMusicService.go();
    }

    //set the mController up
    private void setController(){
        mController = new MusicController(this);
        //set previous and next button listeners
        mController.setPrevNextListeners(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playNext();
            }
        }, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playPrev();
            }
        });
        //set and show
        mController.setMediaPlayer(this);
        mController.setAnchorView(findViewById(R.id.recycler_view));
        mController.setEnabled(true);
    }

    private void playNext(){
        mMusicService.playNext();
        if(mPlaybackPaused){
            setController();
            mPlaybackPaused =false;
        }
        mController.show(0);
    }

    private void playPrev(){
        mMusicService.playPrev();
        if(mPlaybackPaused){
            setController();
            mPlaybackPaused =false;
        }
        mController.show(0);
    }

    //user song select
    public void songPicked(int position){
        mMusicService.setSong(position);
        mMusicService.playSong();
        if(mPlaybackPaused){
            setController();
            mPlaybackPaused =false;
        }
        mController.show(0);
    }
}
