package com.lodhi.neeraj.myjioapp;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.MediaController;

import com.lodhi.neeraj.myjioapp.service.MusicService;

import java.util.ArrayList;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;

/**
 * Created by Neeraj on 2/14/2019.
 */

public class MusicPresenter implements MusicMainInterface.ViewToPresenter {

    private MusicMainInterface.PresenterToView mView;
    private MusicMainInterface.PresenterToModel model;
    private Activity activity;
    private MusicService mMusicService;


    public MusicPresenter(MusicMainInterface.PresenterToView presenterToView, Activity activity) {
        mView = presenterToView;
        this.activity = activity;
        model = new SongModel(new MusicMainInterface.MOdelToPresenter() {
            @Override
            public Context getContext() {
                return mView.getContext();
            }

        });


    }

    @Override
    public void getSongList() {
        SongActivityView songActivityView = (SongActivityView) activity;
        songActivityView.displySongList(model.getSongList());
        //return model.getSongList();
    }

    @Override
    public boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(mView.getContext(), READ_EXTERNAL_STORAGE);


        return (result == PackageManager.PERMISSION_GRANTED) ;
    }

    @Override
    public void requestPermission() {

        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(mView.getContext(),
                READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Permission is not granted
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity,
                    READ_EXTERNAL_STORAGE)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
            } else {
                // No explanation needed; request the permission
                ActivityCompat.requestPermissions(activity,
                        new String[]{READ_EXTERNAL_STORAGE},
                        1);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        } else {
            // Permission has already been granted
        }
    }


}
