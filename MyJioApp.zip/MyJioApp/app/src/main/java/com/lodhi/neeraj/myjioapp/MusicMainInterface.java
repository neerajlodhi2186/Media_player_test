package com.lodhi.neeraj.myjioapp;

import android.content.Context;
import java.util.ArrayList;


/**
 * Created by Neeraj on 2/14/2019.
 */

public class MusicMainInterface {

    /**
     * Operations offered to View to communicate with Presenter.
     * Processes user interactions, sends data requests to Model, etc.
     */
    interface ViewToPresenter {
        void getSongList();
        boolean checkPermission();
        void requestPermission();

    }


    /**
     * Required Presenter methods available to Model.
     */
    interface MOdelToPresenter {
        Context getContext();
    }


    /**
     * Required View methods available to Presenter.
     * A passive layer, responsible to show data
     * and receive user interactions
     */
    interface PresenterToView {
        Context getContext();
    }

    /**
     * All Model methods available to Presenter
     */
    interface PresenterToModel {
        ArrayList<Song> getSongList();
    }

}
